package com.espcontrol;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;


import com.google.android.material.button.MaterialButton;
import com.google.android.material.slider.Slider;

import androidx.appcompat.widget.SwitchCompat;
import java.util.Locale;


public class MainActivity extends AppCompatActivity implements FirebaseManager.DataCallback {


    private FirebaseManager mFirebaseManager;

    private Slider sliderSteering;
    private Slider sliderBraking;
    private TextView txtSteeringValue;
    private SwitchCompat switchEV;
    private SwitchCompat switchHEV;
    private SwitchCompat switchICE;
    private TextView txtBrakingValue;
    private TextView txtStatus;
    private MaterialButton btnGameMode;
    private MaterialButton btnResetSteering;
    private MaterialButton btnResetBraking;
    private MaterialButton btnPing;
    private MaterialButton btnStatistics; // Added statistics button

    private int steeringValue = 90;
    private int brakingValue = 0;
    private int EVmode = 0;
    private int HEVmode = 0;
    private int ICEmode = 0;
    private int brakingStatus = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFirebaseManager = new FirebaseManager(this);

        initializeUI();
        setupListeners();
    }

    private void initializeUI() {
        sliderSteering = findViewById(R.id.seekBarSteering);
        txtSteeringValue = findViewById(R.id.txtSteeringValue);
        btnResetSteering = findViewById(R.id.btnResetSteering);

        sliderBraking = findViewById(R.id.seekBarBraking);
        txtBrakingValue = findViewById(R.id.txtBrakingValue);
        btnResetBraking = findViewById(R.id.btnResetBraking);

        txtStatus = findViewById(R.id.txtStatus);

        switchEV = findViewById(R.id.switchEV);
        switchHEV = findViewById(R.id.switchHEV);
        switchICE = findViewById(R.id.switchICE);

        btnGameMode = findViewById(R.id.btnGameMode);
        btnPing = findViewById(R.id.btnPing);
        btnStatistics = findViewById(R.id.btnStatistics); // Initialize statistics button

        sliderSteering.setValueFrom(0);
        sliderSteering.setValueTo(180);
        sliderSteering.setValue(90);
        sliderSteering.setStepSize(1);

        sliderBraking.setValueFrom(0);
        sliderBraking.setValueTo(180);
        sliderBraking.setValue(0);
        sliderBraking.setStepSize(1);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupListeners() {
        sliderBraking.addOnChangeListener((slider, value, fromUser) -> {
            brakingValue = (int) value;
            txtBrakingValue.setText(String.format(Locale.ENGLISH, getString(R.string.braking_format), brakingValue));
        });

        sliderBraking.setOnTouchListener((v, event) -> {
            v.getParent().requestDisallowInterceptTouchEvent(true);
            return false;
        });

        sliderSteering.addOnChangeListener((slider, value, fromUser) -> {
            steeringValue = (int) value;
            txtSteeringValue.setText(String.format(Locale.ENGLISH, getString(R.string.steering_format), steeringValue));
        });

        switchHEV.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                switchEV.setChecked(false); EVmode = 0;
                switchICE.setChecked(false); ICEmode = 0;
                sliderSteering.setValue(180);
                sliderBraking.setValue(0);

            }
            HEVmode = isChecked ? 1 : 0;
            mFirebaseManager.sendCombinedControlValues(steeringValue, brakingValue, brakingStatus, EVmode, HEVmode, ICEmode);
        });
        switchICE.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                switchHEV.setChecked(false); HEVmode = 0;
                switchEV.setChecked(false); EVmode = 0;
                sliderBraking.setValue(0);
            }
            ICEmode = isChecked ? 1 : 0;
            mFirebaseManager.sendCombinedControlValues(steeringValue, brakingValue, brakingStatus, EVmode, HEVmode, ICEmode);
        });

        switchEV.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                switchHEV.setChecked(false); HEVmode = 0;
                switchICE.setChecked(false); ICEmode = 0;
                sliderBraking.setValue(0);
                sliderBraking.setEnabled(false);
            } else {
                sliderBraking.setEnabled(true);
            }
            EVmode = isChecked ? 1 : 0;
            mFirebaseManager.sendCombinedControlValues(steeringValue, brakingValue,brakingStatus, EVmode, HEVmode, ICEmode);
        });


        sliderSteering.addOnSliderTouchListener(new Slider.OnSliderTouchListener() {
            @Override
            public void onStartTrackingTouch(@NonNull Slider slider) {
            }

            @Override
            public void onStopTrackingTouch(@NonNull Slider slider) {
                mFirebaseManager.sendCombinedControlValues(steeringValue, brakingValue,brakingStatus, EVmode, HEVmode, ICEmode);
                txtStatus.setText(String.format(Locale.ENGLISH, getString(R.string.status_sent_format), steeringValue, brakingValue, brakingStatus, EVmode, HEVmode, ICEmode));
            }
        });

        sliderBraking.addOnChangeListener((slider, value, fromUser) -> {
            brakingValue = (int) value;
            txtBrakingValue.setText(String.format(Locale.ENGLISH, getString(R.string.braking_format), brakingValue));
        });


        sliderBraking.addOnSliderTouchListener(new Slider.OnSliderTouchListener() {
            @Override
            public void onStartTrackingTouch(@NonNull Slider slider) {
            }

            @SuppressLint("StringFormatMatches")
            @Override
            public void onStopTrackingTouch(@NonNull Slider slider) {
                mFirebaseManager.sendCombinedControlValues(steeringValue, brakingValue,brakingStatus, EVmode, HEVmode, ICEmode);
                txtStatus.setText(String.format(Locale.ENGLISH, getString(R.string.status_sent_format), steeringValue, brakingValue, brakingStatus, EVmode, HEVmode, ICEmode));
            }
        });

        btnResetSteering.setOnClickListener(v -> {
            steeringValue = 90;
            sliderSteering.setValue(steeringValue);
            txtStatus.setText(R.string.status_centered);
            mFirebaseManager.sendCombinedControlValues(steeringValue, brakingValue,brakingStatus, EVmode, HEVmode, ICEmode);
        });

        btnResetBraking.setOnClickListener(v -> {
            brakingValue = 0;
            brakingStatus = 1;
            sliderBraking.setValue(brakingValue);
            txtStatus.setText(R.string.status_braking_reset);
            mFirebaseManager.sendCombinedControlValues(steeringValue, brakingValue, brakingStatus, EVmode, HEVmode, ICEmode);
            brakingStatus = 0;
        });

        btnGameMode.setOnClickListener(v -> launchSteeringWheelActivity());

        if (btnPing != null) {
            btnPing.setOnClickListener(v -> {
                txtStatus.setText(R.string.status_pinging);
                // Implement your ping functionality here, e.g., mFirebaseManager.pingESP32();
            });
        }

        // Add click listener for the statistics button
        btnStatistics.setOnClickListener(v -> launchStatisticsActivity());
    }

    private void launchSteeringWheelActivity() {
        Intent intent = new Intent(MainActivity.this, SteeringWheelActivity.class);
        intent.putExtra("STEERING_VALUE", steeringValue);
        intent.putExtra("BRAKING_VALUE", brakingValue);
        startActivity(intent);
        txtStatus.setText(R.string.status_launching_game_mode);
    }

    // Add method to launch the Statistics Activity
    private void launchStatisticsActivity() {
        Intent intent = new Intent(MainActivity.this, StatisticsActivity.class);
        startActivity(intent);
        txtStatus.setText(R.string.status_viewing_statistics);
    }

    @Override
    public void onCommandSent(boolean success, String command, @Nullable String error) {
        String statusMessage;
        if (success) {
            statusMessage = String.format(Locale.ENGLISH, getString(R.string.status_success_format), command);
        } else {
            statusMessage = String.format(Locale.ENGLISH, getString(R.string.status_error_format), command, error);
        }
        txtStatus.setText(statusMessage);
    }

    @Override
    public void onInitialControlValues(int steering, int braking) {
        steeringValue = steering;
        brakingValue = braking;
        sliderSteering.setValue(steering);
        sliderBraking.setValue(braking);
        txtSteeringValue.setText(String.format(Locale.ENGLISH, getString(R.string.steering_format), steering));
        txtBrakingValue.setText(String.format(Locale.ENGLISH, getString(R.string.braking_format), braking));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mFirebaseManager != null) {
            mFirebaseManager.cleanup();
        }
    }
}