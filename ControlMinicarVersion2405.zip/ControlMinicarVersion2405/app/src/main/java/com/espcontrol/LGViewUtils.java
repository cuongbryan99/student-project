package com.espcontrol;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;

import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class LGViewUtils {

    public static int dp2px(Context context, int dp) {
        return (int) (dp * context.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static int px2dp(Context context, int px) {
        return (int) (px / context.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static int getScreenWidth(Context context) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        return displayMetrics.widthPixels;
    }

    public static int getScreenHeight(Context context) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        return displayMetrics.heightPixels;
    }

    public static void setFullscreen(Activity activity, boolean on) {
        Window win = activity.getWindow();
        if (on) {
            win.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        } else {
            win.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
    }

    public static boolean isFullScreen(Activity activity) {
        return (activity.getWindow().getAttributes().flags & WindowManager.LayoutParams.FLAG_FULLSCREEN) != 0;
    }

    public static void rotateScreen(Activity activity) {
        if (activity.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        } else {
            activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }

    public static void enableDisableView(View view, boolean enabled) {
        view.setEnabled(enabled);

        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                enableDisableView(((ViewGroup) view).getChildAt(i), enabled);
            }
        }
    }

    public static boolean isChildOf(View root, View child) {
        if (root == child)
            return true;

        if (root instanceof ViewGroup) {
            int count = ((ViewGroup) root).getChildCount();
            for (int i = 0; i < count; i++) {
                View v = ((ViewGroup) root).getChildAt(i);
                if (isChildOf(v, child))
                    return true;
            }
        }

        return false;
    }

    public static int getStatusBarHeight(View view) {
        WindowInsetsCompat insets = ViewCompat.getRootWindowInsets(view);
        if (insets != null) {
            return insets.getInsets(WindowInsetsCompat.Type.systemBars()).top;
        }
        return 0;
    }

    public static Bitmap createBitmapFromView(View v) {
        if (v == null) {
            return null;
        }
        Bitmap screenshot;
        screenshot = Bitmap.createBitmap(v.getWidth(), v.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(screenshot);
        c.translate(-v.getScrollX(), -v.getScrollY());
        v.draw(c);
        return screenshot;
    }

    public static boolean saveBitmap2Disk(Context context, Bitmap bitmap, String directoryName, String fileName) {
        File folder = context.getExternalFilesDir(directoryName);

        if (folder == null) {
            return false;
        }

        if (!folder.exists()) {
            if (!folder.mkdirs()) {
                return false;
            }
        }

        File outputFile = new File(folder, fileName);

        try {
            if (outputFile.exists()) {
                if (!outputFile.delete()) {
                    return false;
                }
            }

            FileOutputStream out = new FileOutputStream(outputFile);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.flush();
            out.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void setTransparent(Context context, View view) {
        try {
            view.setBackgroundColor(ContextCompat.getColor(context, android.R.color.transparent));
        } catch (Exception e) {
            e.printStackTrace();
            view.setBackgroundColor(Color.TRANSPARENT);
        }
    }

    public static void viewAnim(Context context, View view, int animId) {
        view.startAnimation(AnimationUtils.loadAnimation(context, animId));
    }
}