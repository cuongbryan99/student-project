package com.espcontrol;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TimeInterpolator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.OvershootInterpolator;

import androidx.annotation.NonNull;

public class SteeringWheelView extends View {
    public static final int INVALID = -1;
    public static final int RIGHT = 0;
    public static final int UP = 1;
    public static final int LEFT = 2;
    public static final int DOWN = 4;

    private static final int STEERING_CENTER_VALUE = 90;

    private SteeringWheelListener mListener;
    private final Paint mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int mColor;
    private float mCenterX;
    private float mCenterY;
    private Drawable mBallDrawable;
    private Drawable mBallPressedDrawable;
    private float mBallCenterX;
    private float mBallCenterY;
    private float mBallRadius;
    private float mRadius;
    private double mAngle;
    private int mPower;
    private long mNotifyInterval = 0;
    private Runnable mNotifyRunnable;
    private long mLastNotifyTime;
    private int mDirection = INVALID;
    private Drawable mArrowRightDrawable;
    private ObjectAnimator mAnimator;
    private TimeInterpolator mInterpolator;
    private boolean mWasTouched;
    private int mLinearHorizontalSteeringValue = STEERING_CENTER_VALUE;

    public float getBallX() {
        return mBallCenterX;
    }

    public void setBallX(float ballX) {
        if (ballX != mBallCenterX) {
            mBallCenterX = ballX;
            updateLinearSteeringValue();
            updatePower();
            updateDirection();
            invalidate();
            notifyStatusChanged();
        }
    }

    public float getBallY() {
        return mBallCenterY;
    }

    public void setBallY(float ballY) {
        if (mBallCenterY != ballY) {
            mBallCenterY = ballY;
            updateLinearSteeringValue();
            updatePower();
            updateDirection();
            invalidate();
            notifyStatusChanged();
        }
    }

    public SteeringWheelView(Context context) {
        super(context);
        init(null, 0);
    }

    public SteeringWheelView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(attrs, 0);
    }

    public SteeringWheelView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(attrs, defStyle);
    }

    private void init(AttributeSet attrs, int defStyle) {
        final int mDefaultWidthDp = 200;
        final int mDefaultHeightDp = 200;

        if (attrs != null) {
            TypedArray a = getContext().obtainStyledAttributes(attrs, R.styleable.SteeringWheelView);
            mColor = a.getColor(R.styleable.SteeringWheelView_ballColor, Color.RED);
            mArrowRightDrawable = a.getDrawable(R.styleable.SteeringWheelView_arrowRight);
            mBallDrawable = a.getDrawable(R.styleable.SteeringWheelView_ballSrc);
            mBallPressedDrawable = a.getDrawable(R.styleable.SteeringWheelView_ballPressedSrc);
            a.recycle();
        } else {
            mColor = Color.RED;
        }

        if (mBallDrawable != null) {
            mBallRadius = mBallDrawable.getIntrinsicWidth() >> 1;
        } else {
            mBallRadius = dp2px(getContext(), 20);
        }

        mPaint.setColor(mColor);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeWidth(dp2px(getContext(), 2));
    }

    private int dp2px(Context context, int dp) {
        return (int) (dp * context.getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        final int paddingLeft = getPaddingLeft();
        final int paddingRight = getPaddingRight();
        final int paddingTop = getPaddingTop();
        final int paddingBottom = getPaddingBottom();

        int width = getWidth() - paddingLeft - paddingRight;
        int height = getHeight() - paddingTop - paddingBottom;

        mCenterX = paddingLeft + (width >> 1);
        mCenterY = paddingTop + (height >> 1);

        int arrowWidth = (mArrowRightDrawable != null) ? mArrowRightDrawable.getIntrinsicWidth() / 2 : 0;
        mRadius = (Math.min(width, height) >> 1) - Math.max(arrowWidth, (int)mBallRadius);

        mBallCenterX = mCenterX;
        mBallCenterY = mCenterY;
        mLinearHorizontalSteeringValue = STEERING_CENTER_VALUE;

        if (mArrowRightDrawable != null) {
            int arrowHalfWidth = mArrowRightDrawable.getIntrinsicWidth() / 2;
            int arrowHalfHeight = mArrowRightDrawable.getIntrinsicHeight() / 2;
            mArrowRightDrawable.setBounds(
                    (int) (mCenterX + mRadius - arrowHalfWidth),
                    (int) (mCenterY - arrowHalfHeight),
                    (int) (mCenterX + mRadius + arrowHalfWidth),
                    (int) (mCenterY + arrowHalfHeight)
            );
        }
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawLine(mCenterX - mRadius, mCenterY, mCenterX + mRadius, mCenterY, mPaint);
        canvas.drawLine(mCenterX, mCenterY - mRadius, mCenterX, mCenterY + mRadius, mPaint);
        canvas.drawCircle(mCenterX, mCenterY, mRadius, mPaint);
        drawBall(canvas);
        drawArrow(canvas);
    }

    private void drawBall(@NonNull Canvas canvas) {
        Drawable drawable;
        if (mWasTouched && mBallPressedDrawable != null) {
            drawable = mBallPressedDrawable;
        } else if (mBallDrawable != null) {
            drawable = mBallDrawable;
        } else {
            Paint ballPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            ballPaint.setColor(mColor);
            ballPaint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(mBallCenterX, mBallCenterY, mBallRadius, ballPaint);
            return;
        }

        int ballHalfWidth = drawable.getIntrinsicWidth() / 2;
        int ballHalfHeight = drawable.getIntrinsicHeight() / 2;
        drawable.setBounds(
                (int) (mBallCenterX - ballHalfWidth),
                (int) (mBallCenterY - ballHalfHeight),
                (int) (mBallCenterX + ballHalfWidth),
                (int) (mBallCenterY + ballHalfHeight)
        );
        drawable.draw(canvas);
    }

    private void drawArrow(@NonNull Canvas canvas) {
        if (!mWasTouched || mArrowRightDrawable == null)
            return;

        canvas.save();
        canvas.rotate((float) -mAngle, mCenterX, mCenterY);
        mArrowRightDrawable.draw(canvas);
        canvas.restore();
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(@NonNull MotionEvent event) {
        int x = (int) event.getX();
        int y = (int) event.getY();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN: {
                mWasTouched = true;
                if (mAnimator != null && mAnimator.isRunning()) {
                    mAnimator.cancel();
                }
                updateBallData(x, y);
                break;
            }
            case MotionEvent.ACTION_MOVE: {
                updateBallData(x, y);
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                mWasTouched = false;
                resetBall();
                break;
            }
            default:
                return super.onTouchEvent(event);
        }

        notifyStatusChanged();
        performClick();

        return true;
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    public SteeringWheelView interpolator(TimeInterpolator value) {
        if (value != null) {
            mInterpolator = value;
        } else {
            mInterpolator = new OvershootInterpolator();
        }
        return this;
    }

    private TimeInterpolator getInterpolator() {
        if (mInterpolator == null) {
            mInterpolator = new OvershootInterpolator();
        }
        return mInterpolator;
    }

    private void resetBall() {
        PropertyValuesHolder pvhX = PropertyValuesHolder.ofFloat("BallX", mBallCenterX, mCenterX);
        PropertyValuesHolder pvhY = PropertyValuesHolder.ofFloat("BallY", mBallCenterY, mCenterY);
        mAnimator = ObjectAnimator.ofPropertyValuesHolder(this, pvhX, pvhY).setDuration(150);
        mAnimator.setInterpolator(getInterpolator());
        mAnimator.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(@NonNull Animator animation) {
            }

            @Override
            public void onAnimationEnd(@NonNull Animator animation) {
                mAngle = 0;
                mPower = 0;
                mDirection = INVALID;
                mBallCenterX = mCenterX;
                mBallCenterY = mCenterY;
                mLinearHorizontalSteeringValue = STEERING_CENTER_VALUE;
                notifyStatusChanged();
                invalidate();
            }

            @Override
            public void onAnimationCancel(@NonNull Animator animation) {
                updateLinearSteeringValue();
                updatePower();
                updateDirection();
                notifyStatusChanged();
                invalidate();
            }

            @Override
            public void onAnimationRepeat(@NonNull Animator animation) {
            }
        });
        mAnimator.start();
    }

    private void updateBallData(int x, int y) {
        double deltaX = x - mCenterX;
        double deltaY = y - mCenterY;
        double distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
        float maxDraggableRadius = mRadius - mBallRadius;

        if (maxDraggableRadius <= 0) {
            mBallCenterX = mCenterX;
            mBallCenterY = mCenterY;
        } else if (distance > maxDraggableRadius) {
            double ratio = maxDraggableRadius / distance;
            mBallCenterX = (float) (mCenterX + deltaX * ratio);
            mBallCenterY = (float) (mCenterY + deltaY * ratio);
        } else {
            mBallCenterX = x;
            mBallCenterY = y;
        }

        updateLinearSteeringValue();

        mAngle = Math.toDegrees(Math.atan2( -(mBallCenterY - mCenterY), (mBallCenterX - mCenterX) ));
        if (mAngle < 0) {
            mAngle += 360;
        }

        updatePower();
        updateDirection();
        invalidate();
    }

    private void updateLinearSteeringValue() {
        float maxHorizontalDisplacement = mRadius - mBallRadius;
        if (maxHorizontalDisplacement > 0.001f) {
            float deltaX = mBallCenterX - mCenterX;
            float normalizedX = deltaX / maxHorizontalDisplacement;
            normalizedX = Math.max(-1.0f, Math.min(1.0f, normalizedX));
            mLinearHorizontalSteeringValue = Math.round(STEERING_CENTER_VALUE - (normalizedX * STEERING_CENTER_VALUE));
            mLinearHorizontalSteeringValue = Math.min(180, Math.max(0, mLinearHorizontalSteeringValue));
        } else {
            mLinearHorizontalSteeringValue = STEERING_CENTER_VALUE;
        }
    }

    private void updatePower() {
        double distance = Math.sqrt(Math.pow(mBallCenterX - mCenterX, 2) + Math.pow(mBallCenterY - mCenterY, 2));
        float maxDraggableRadius = mRadius - mBallRadius;
        if (maxDraggableRadius > 0.001f) {
            mPower = (int) (100 * distance / maxDraggableRadius);
            mPower = Math.min(100, Math.max(0, mPower));
        } else {
            mPower = 0;
        }
    }

    private int updateDirection() {
        if (mPower < 5) {
            mDirection = INVALID;
        } else if (mAngle >= 315 || mAngle < 45) {
            mDirection = RIGHT;
        } else if (mAngle >= 45 && mAngle < 135) {
            mDirection = UP;
        } else if (mAngle >= 135 && mAngle < 225) {
            mDirection = LEFT;
        } else {
            mDirection = DOWN;
        }
        return mDirection;
    }

    private void notifyStatusChanged() {
        if (mListener == null)
            return;

        long delay = 0;
        if (mNotifyInterval > 0) {
            if (mNotifyRunnable == null) {
                mNotifyRunnable = createNotifyRunnable();
            }
            long now = System.currentTimeMillis();
            if (now - mLastNotifyTime < mNotifyInterval) {
                removeCallbacks(mNotifyRunnable);
                delay = mNotifyInterval - (now - mLastNotifyTime);
            }
            postDelayed(mNotifyRunnable, delay);
        } else {
            mLastNotifyTime = System.currentTimeMillis();
            mListener.onStatusChanged(this, (int) mAngle, mPower, mDirection, mLinearHorizontalSteeringValue);
        }
    }

    private Runnable createNotifyRunnable() {
        return () -> {
            mLastNotifyTime = System.currentTimeMillis();
            mListener.onStatusChanged(this, (int) mAngle, mPower, mDirection, mLinearHorizontalSteeringValue);
        };
    }

    public SteeringWheelView notifyInterval(long interval) {
        if (interval < 0) {
            throw new IllegalArgumentException("notifyInterval interval < 0 is not accept");
        }

        mNotifyInterval = interval;
        return this;
    }

    public SteeringWheelView listener(SteeringWheelListener listener) {
        mListener = listener;
        if (mListener != null) {
            mListener.onStatusChanged(this, (int) mAngle, mPower, mDirection, mLinearHorizontalSteeringValue);
        }
        return this;
    }

    // Add this method to allow external setting of the angle
    public void setAngle(int angle) {
        // Convert angle (0-180) back to the internal representation if needed,
        // or directly update the visual state based on the angle.
        // This implementation assumes the angle directly corresponds to
        // mLinearHorizontalSteeringValue and updates the visual ball position.

        mLinearHorizontalSteeringValue = Math.min(180, Math.max(0, angle));

        // Calculate normalized X based on the linear steering value
        float normalizedX = -((float)(mLinearHorizontalSteeringValue - STEERING_CENTER_VALUE) / STEERING_CENTER_VALUE);
        normalizedX = Math.max(-1.0f, Math.min(1.0f, normalizedX));

        float maxHorizontalDisplacement = mRadius - mBallRadius;
        if (maxHorizontalDisplacement > 0.001f) {
            mBallCenterX = mCenterX + normalizedX * maxHorizontalDisplacement;
            // Keep Y centered for simplicity when setting externally,
            // or calculate based on angle if a circular movement is desired.
            mBallCenterY = mCenterY;
        } else {
            mBallCenterX = mCenterX;
            mBallCenterY = mCenterY;
        }


        // Recalculate angle, power, direction based on new ball position
        double deltaX = mBallCenterX - mCenterX;
        double deltaY = mBallCenterY - mCenterY; // Will be 0 in this simplified case
        mAngle = Math.toDegrees(Math.atan2(-deltaY, deltaX));
        if (mAngle < 0) {
            mAngle += 360;
        }

        updatePower(); // Recalculate power based on new position
        updateDirection(); // Recalculate direction

        invalidate(); // Redraw the view with the new ball position
        // Optionally, notify listener if external changes should trigger it
        // notifyStatusChanged();
    }


    public interface SteeringWheelListener {
        void onStatusChanged(SteeringWheelView view, int displayAngle, int power, int direction, int linearSteeringValue);
    }
}