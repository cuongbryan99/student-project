package com.espcontrol;

import android.util.Log;

import androidx.annotation.Nullable;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * FirebaseManager handles all Firebase Realtime Database operations
 * for the ESP32 Controller app.
 */
public class FirebaseManager {
    private static final String TAG = "FirebaseManager";

    // Firebase paths
    private static final String PATH_CONTROLS = "devices/esp32s3/controls";

    // Firebase references
    private final DatabaseReference mControlsRef;

    // Data callback interface
    public interface DataCallback {
        void onCommandSent(boolean success, String command, @Nullable String error);
        void onInitialControlValues(int steering, int braking);
    }

    private DataCallback mCallback;

    // Make command logger static so it persists across activities
    private static CommandLogger sCommandLogger;

    /**
     * Constructor initializes Firebase references
     * @param callback The callback to notify of data changes
     */
    public FirebaseManager(DataCallback callback) {
        mCallback = callback;

        // Initialize Firebase references
        mControlsRef = FirebaseDatabase.getInstance().getReference().child(PATH_CONTROLS);

        // Initialize command logger if it hasn't been initialized yet
        if (sCommandLogger == null) {
            sCommandLogger = new CommandLogger(null);
        }

        // Fetch initial control values
        fetchCurrentControlValues();
    }

    /**
     * Fetch current control values from Firebase
     */
    public void fetchCurrentControlValues() {
        mControlsRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DataSnapshot snapshot = task.getResult();
                if (snapshot != null) {
                    // Safely handle potential null values
                    Integer steeringValue = snapshot.child("steering").getValue(Integer.class);
                    Integer brakingValue = snapshot.child("braking").getValue(Integer.class);

                    // Use defaults if null
                    int steering = (steeringValue != null) ? steeringValue : 90; // Default steering
                    int braking = (brakingValue != null) ? brakingValue : 0;     // Default braking

                    if (mCallback != null) {
                        mCallback.onInitialControlValues(steering, braking);
                    }
                }
            } else {
                Log.e(TAG, "Error fetching initial control values", task.getException());
                // Optionally, notify callback of failure or use defaults
                if (mCallback != null) {
                    mCallback.onInitialControlValues(90, 0); // Default values on error
                }
            }
        });
    }

    /**
     * Send combined steering and braking values to Firebase
     * @param steering The steering value (0-180)
     * @param braking The braking value (0-180)
     */
    public void sendCombinedControlValues(int steering, int braking, int braking_status,  int EVmode, int HEVmode , int ICEmode) {
        // Increment command counter if logging is active
        if (sCommandLogger != null && sCommandLogger.isLogging()) {
            sCommandLogger.incrementCommandCount();
        }

        // Constrain values to valid ranges
        steering = Math.max(0, Math.min(180, steering));
        braking = Math.max(0, Math.min(180, braking));

        String ServoMode;


        if (EVmode == 1) {
            ServoMode = ", Front Clutch=180, Rear Clutch=0, Starting=0";
            mControlsRef.child("servo1").setValue(180);
            mControlsRef.child("servo2").setValue(0);
            mControlsRef.child("servo6").setValue(0);
            mControlsRef.child("braking").setValue(braking_status);
        } else if (ICEmode == 1) {
            ServoMode = ", Front Clutch=0, Rear Clutch=180, Starting=180";
            mControlsRef.child("servo1").setValue(0);
            mControlsRef.child("servo2").setValue(180);
            mControlsRef.child("servo6").setValue(180);
            mControlsRef.child("braking").setValue(braking_status);
        } else if (HEVmode == 1) {
            ServoMode = ", Front Clutch=180, Rear Clutch=180, Starting=180";
            mControlsRef.child("servo1").setValue(180);
            mControlsRef.child("servo2").setValue(180);
            mControlsRef.child("servo6").setValue(180);
            mControlsRef.child("braking").setValue(braking_status);

        } else {
            ServoMode = "";
        }

        // Update Firebase
        mControlsRef.child("steering").setValue(steering);
        // It's good practice to use final variables for lambdas if they are accessed from inner classes
        final int finalSteering = steering;
        final int finalSpeed = braking;


        mControlsRef.child("steering").setValue(steering);

        mControlsRef.child("speed").setValue(braking)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Combined control values sent: Steering=" + finalSteering + ", Speed=" + finalSpeed + ", Braking=" + braking_status + ServoMode);
                    if (mCallback != null) {
                        mCallback.onCommandSent(true, "Steering=" + finalSteering + ", Speed=" +  finalSpeed + ", Braking=" + braking_status + ServoMode, null);
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error sending combined control values", e);
                    if (mCallback != null) {
                        mCallback.onCommandSent(false, "Steering=" + finalSteering + ", Speed=" +  finalSpeed + ", Braking=" + braking_status + ServoMode, e.getMessage());
                    }
                });
    }

    /**
     * Start command logging with specified parameters
     * @param intervalSeconds Seconds between each logging step
     * @param durationSeconds Total duration to log for
     * @return true if logging started successfully
     */
    public boolean startCommandLogging(int intervalSeconds, int durationSeconds) {
        return sCommandLogger != null && sCommandLogger.startLogging(intervalSeconds, durationSeconds);
    }

    /**
     * Stop command logging and upload results
     */
    public void stopCommandLogging() {
        if (sCommandLogger != null) {
            sCommandLogger.stopLogging();
        }
    }

    /**
     * Check if command logging is active
     * @return true if logging is in progress
     */
    public boolean isLogging() {
        return sCommandLogger != null && sCommandLogger.isLogging();
    }

    /**
     * Set a logging status callback
     * @param callback The callback to notify of logging status changes
     */
    public void setLoggingCallback(CommandLogger.LoggingStatusCallback callback) {
        if (sCommandLogger != null) {
            sCommandLogger.setCallback(callback);
        }
    }

    /**
     * Clean up any listeners when the app is closed
     */
    public void cleanup() {
        // Log disconnect
        Log.d(TAG, "FirebaseManager cleanup - user disconnected at " + getTimestamp());

        // Don't destroy sCommandLogger here to allow background logging
        // Just release this instance's callback
        mCallback = null;
    }

    /**
     * Get formatted timestamp for logs
     * @return Current timestamp in UTC as a formatted string
     */
    public String getTimestamp() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date());
    }
}