package com.espcontrol;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public class StatisticsActivity extends AppCompatActivity implements CommandLogger.LoggingStatusCallback {

    private static final String PATH_STATISTICS = "devices/esp32s3/statistics";

    private TextView txtLoggingStatus;
    private Button btnStartLogging;
    private Button btnStopLogging;
    private EditText editInterval;
    private EditText editDuration;
    private Spinner spinnerSessions;
    private LineChart chartCommandStats;

    private FirebaseManager mFirebaseManager;
    private DatabaseReference mStatisticsRef;
    private final List<String> mSessionIds = new ArrayList<>();
    private final Map<String, Map<String, Object>> mSessionsData = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);

        // Show back button in the action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.title_statistics);
        }

        mFirebaseManager = new FirebaseManager(null);  // We don't need the callback here
        // Set this activity as the logging callback
        mFirebaseManager.setLoggingCallback(this);
        mStatisticsRef = FirebaseDatabase.getInstance().getReference().child(PATH_STATISTICS);

        initializeUI();
        setupListeners();
        fetchSessionsList();

        // Update UI based on current logging status
        updateLoggingUI(mFirebaseManager.isLogging());
    }

    private void initializeUI() {
        txtLoggingStatus = findViewById(R.id.txtLoggingStatus);
        btnStartLogging = findViewById(R.id.btnStartLogging);
        btnStopLogging = findViewById(R.id.btnStopLogging);
        editInterval = findViewById(R.id.editInterval);
        editDuration = findViewById(R.id.editDuration);
        spinnerSessions = findViewById(R.id.spinnerSessions);
        chartCommandStats = findViewById(R.id.chartCommandStats);

        // Setup chart appearance
        setupChart();

        // Default values
        editInterval.setText("1");
        editDuration.setText("60");
        updateLoggingUI(false);
    }

    private void setupChart() {
        chartCommandStats.getDescription().setEnabled(false);
        chartCommandStats.setTouchEnabled(true);
        chartCommandStats.setDragEnabled(true);
        chartCommandStats.setScaleEnabled(true);
        chartCommandStats.setPinchZoom(true);
        chartCommandStats.setDrawGridBackground(false);

        // X-axis setup
        XAxis xAxis = chartCommandStats.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f);
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return String.valueOf((int) value);
            }
        });

        // Hide right axis
        chartCommandStats.getAxisRight().setEnabled(false);

        // Left axis
        chartCommandStats.getAxisLeft().setDrawGridLines(true);
        chartCommandStats.getAxisLeft().setAxisMinimum(0f);

        // Legend
        chartCommandStats.getLegend().setEnabled(true);

        // Empty data
        chartCommandStats.setData(new LineData());
        chartCommandStats.invalidate();
    }

    private void setupListeners() {
        btnStartLogging.setOnClickListener(v -> {
            try {
                int interval = Integer.parseInt(editInterval.getText().toString());
                int duration = Integer.parseInt(editDuration.getText().toString());

                if (interval <= 0 || duration <= 0) {
                    Toast.makeText(this, R.string.error_invalid_values, Toast.LENGTH_SHORT).show();
                    return;
                }

                if (duration < interval) {
                    Toast.makeText(this, R.string.error_duration_too_short, Toast.LENGTH_SHORT).show();
                    return;
                }

                if (mFirebaseManager.startCommandLogging(interval, duration)) {
                    updateLoggingUI(true);
                    Toast.makeText(this, R.string.msg_logging_started, Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, R.string.error_invalid_input, Toast.LENGTH_SHORT).show();
            }
        });

        btnStopLogging.setOnClickListener(v -> {
            mFirebaseManager.stopCommandLogging();
            updateLoggingUI(false);
            Toast.makeText(this, R.string.msg_logging_stopped, Toast.LENGTH_SHORT).show();

            // Refresh sessions list after stopping
            fetchSessionsList();
        });

        spinnerSessions.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position > 0) {
                    String sessionId = mSessionIds.get(position);
                    loadSessionData(sessionId);
                } else {
                    // First item is prompt - clear chart
                    chartCommandStats.clear();
                    chartCommandStats.invalidate();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }

    private void updateLoggingUI(boolean isLogging) {
        btnStartLogging.setEnabled(!isLogging);
        btnStopLogging.setEnabled(isLogging);
        editInterval.setEnabled(!isLogging);
        editDuration.setEnabled(!isLogging);

        if (isLogging) {
            txtLoggingStatus.setText(R.string.status_logging_active);
        } else {
            txtLoggingStatus.setText(R.string.status_logging_inactive);
        }
    }

    private void fetchSessionsList() {
        mStatisticsRef.child("sessions").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                mSessionIds.clear();
                mSessionsData.clear();

                // Add prompt as first item
                mSessionIds.add(getString(R.string.prompt_select_session));

                for (DataSnapshot sessionSnapshot : snapshot.getChildren()) {
                    String sessionId = sessionSnapshot.getKey();
                    if (sessionId != null) {
                        mSessionIds.add(sessionId);

                        // Store session data
                        Map<String, Object> sessionData = new HashMap<>();
                        for (DataSnapshot child : sessionSnapshot.getChildren()) {
                            sessionData.put(child.getKey(), child.getValue());
                        }
                        mSessionsData.put(sessionId, sessionData);
                    }
                }

                // Sort sessions by ID (which is timestamp-based) in descending order
                if (mSessionIds.size() > 1) {
                    List<String> sessionsToSort = mSessionIds.subList(1, mSessionIds.size());
                    sessionsToSort.sort(Collections.reverseOrder());
                }

                // Update spinner
                ArrayAdapter<String> adapter = new ArrayAdapter<>(
                        StatisticsActivity.this,
                        android.R.layout.simple_spinner_item,
                        mSessionIds);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerSessions.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(StatisticsActivity.this,
                        getString(R.string.error_loading_data, error.getMessage()),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    @SuppressWarnings("unchecked")
    private void loadSessionData(String sessionId) {
        Map<String, Object> sessionData = mSessionsData.get(sessionId);
        if (sessionData == null) {
            return;
        }

        // Get time series data
        Map<String, Object> timeSeriesRaw = (Map<String, Object>) sessionData.get("time_series");
        Integer intervalSeconds = sessionData.get("interval_seconds") instanceof Long ?
                ((Long) Objects.requireNonNull(sessionData.get("interval_seconds"))).intValue() : 1;

        if (timeSeriesRaw == null) {
            return;
        }

        // Convert data to chart format
        List<Entry> entries = new ArrayList<>();

        for (Map.Entry<String, Object> entry : timeSeriesRaw.entrySet()) {
            try {
                int timeStep = Integer.parseInt(entry.getKey());
                float commandCount = ((Number) entry.getValue()).floatValue();
                entries.add(new Entry(timeStep, commandCount));
            } catch (NumberFormatException | ClassCastException e) {
                // Skip invalid entries
            }
        }

        // Sort entries by X value
        entries.sort((e1, e2) -> Float.compare(e1.getX(), e2.getX()));

        // Create dataset
        LineDataSet dataSet = new LineDataSet(entries, getString(R.string.chart_label_commands));
        dataSet.setDrawCircles(true);
        dataSet.setCircleRadius(4f);
        dataSet.setDrawValues(true);
        dataSet.setValueTextSize(10f);
        dataSet.setLineWidth(2f);
        dataSet.setColor(getResources().getColor(R.color.colorPrimary, null));
        dataSet.setCircleColor(getResources().getColor(R.color.colorPrimary, null));

        // Set chart data
        LineData lineData = new LineData(dataSet);
        chartCommandStats.setData(lineData);
        chartCommandStats.invalidate();

        // Set chart title with session info
        String timestamp = (String) sessionData.get("timestamp");
        Integer totalCommands = sessionData.get("total_commands") instanceof Long ?
                ((Long) Objects.requireNonNull(sessionData.get("total_commands"))).intValue() : 0;

        Objects.requireNonNull(getSupportActionBar()).setSubtitle(String.format(Locale.US,
                "%s - %d %s (%d%s)",
                timestamp,
                totalCommands,
                getString(R.string.label_commands),
                intervalSeconds,
                getString(R.string.label_sec_interval)));
    }

    // Update callback methods to match new CommandLogger.LoggingStatusCallback interface
    @Override
    public void onLoggingStarted(String sessionId) {
        runOnUiThread(() -> {
            updateLoggingUI(true);
            txtLoggingStatus.setText(getString(R.string.status_logging_started, sessionId));
        });
    }

    @Override
    public void onLoggingStep(int step, int commandCount, int totalSteps) {
        runOnUiThread(() -> txtLoggingStatus.setText(getString(R.string.status_logging_progress,
                step, totalSteps, commandCount)));
    }

    @Override
    public void onLoggingCompleted(String sessionId, int totalCommands) {
        runOnUiThread(() -> {
            updateLoggingUI(false);
            txtLoggingStatus.setText(getString(R.string.status_logging_completed, totalCommands));
            fetchSessionsList();

            // Select the new session
            for (int i = 0; i < mSessionIds.size(); i++) {
                if (mSessionIds.get(i).equals(sessionId)) {
                    spinnerSessions.setSelection(i);
                    break;
                }
            }
        });
    }

    @Override
    public void onLoggingError(String errorMessage) {
        runOnUiThread(() -> {
            Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show();
            updateLoggingUI(false);
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mFirebaseManager != null) {
            // Only clear the callback, don't stop logging if it's running
            mFirebaseManager.setLoggingCallback(null);
            mFirebaseManager.cleanup();
        }
    }
}