// SteeringWheelActivity.java
package com.espcontrol;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Locale;
import java.util.Objects;

public class SteeringWheelActivity extends AppCompatActivity
        implements SteeringWheelView.SteeringWheelListener, FirebaseManager.DataCallback {

    private float brakeIncreaseRatePerMs = 0.1f;
    private float brakeDecreaseRatePerMs = 0.05f;
    private static final int MAX_BRAKING_VALUE = 180;
    private static final int UPDATE_INTERVAL_MS = 16;
    private static final int STEERING_CENTER_VALUE = 90;

    private static final String PREFS_NAME = "BrakeSettings";
    private static final String KEY_INCREASE_RATE = "increaseRate";
    private static final String KEY_DECREASE_RATE = "decreaseRate";

    private SteeringWheelView mSteeringWheel;
    private TextView txtSteeringInfo;
    private TextView txtStatus;
    private TextView txtBrakingValue;
    private MaterialButton btnBrake;
    private MaterialButton btnReturn;
    private MaterialButton btnSettings;

    private FirebaseManager mFirebaseManager;

    private volatile int steeringAngle = STEERING_CENTER_VALUE;
    private volatile float brakingValue = 0;
    private volatile String currentDirection = "";

    private final Handler controlUpdateHandler = new Handler(Looper.getMainLooper());
    private Runnable brakeUpdateRunnable;
    private long lastBrakeUpdateTime;
    private volatile boolean isBrakeButtonHeld = false;
    private volatile boolean isBrakeRunnableScheduled = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_steering_wheel);
        hideSystemUI();
        loadBrakeSettings();
        mFirebaseManager = new FirebaseManager(this);

        if (getIntent().hasExtra("STEERING_VALUE")) {
            steeringAngle = getIntent().getIntExtra("STEERING_VALUE", STEERING_CENTER_VALUE);
        }

        initializeUI();
        setupListeners();
        setupBrakeRunnable();
        updateDirectionText(SteeringWheelView.INVALID);
        mFirebaseManager.fetchCurrentControlValues();
    }

    private void hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
    }


    private void initializeUI() {
        mSteeringWheel = findViewById(R.id.steeringWheelView);
        txtSteeringInfo = findViewById(R.id.txtSteeringInfo);
        txtStatus = findViewById(R.id.txtStatus);
        txtBrakingValue = findViewById(R.id.txtBrakingValue);
        btnBrake = findViewById(R.id.btnBrake);
        btnReturn = findViewById(R.id.btnReturn);
        btnSettings = findViewById(R.id.btnSettings);

        btnReturn.setText(R.string.button_return);
        btnBrake.setText(R.string.button_brake);
        btnSettings.setText(R.string.button_settings);
        txtStatus.setText(R.string.status_ready);
        updateBrakingUI();
        updateSteeringUI(90, 0);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupListeners() {
        mSteeringWheel.notifyInterval(UPDATE_INTERVAL_MS)
                .listener(this)
                .interpolator(new OvershootInterpolator());

        btnBrake.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    if (!isBrakeButtonHeld) {
                        isBrakeButtonHeld = true;
                        lastBrakeUpdateTime = System.currentTimeMillis();
                        startBrakeUpdates();
                        v.setPressed(true);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (isBrakeButtonHeld) {
                        isBrakeButtonHeld = false;
                        startBrakeUpdates();
                        v.setPressed(false);
                        if (event.getAction() == MotionEvent.ACTION_UP) {
                            v.performClick();
                        }
                    }
                    return true;
            }
            return false;
        });

        btnReturn.setOnClickListener(view -> finish());
        btnSettings.setOnClickListener(v -> showSettingsDialog());
    }

    private void startBrakeUpdates() {
        if (!isBrakeRunnableScheduled) {
            isBrakeRunnableScheduled = true;
            controlUpdateHandler.post(brakeUpdateRunnable);
        }
    }

    private void setupBrakeRunnable() {
        brakeUpdateRunnable = new Runnable() {
            @Override
            public void run() {
                long now = System.currentTimeMillis();
                long timeDelta = Math.min(now - lastBrakeUpdateTime, UPDATE_INTERVAL_MS * 5);
                lastBrakeUpdateTime = now;

                boolean valueChanged = false;
                float currentBraking = brakingValue;

                if (isBrakeButtonHeld) {
                    if (currentBraking < MAX_BRAKING_VALUE) {
                        currentBraking += brakeIncreaseRatePerMs * timeDelta;
                        currentBraking = Math.min(currentBraking, MAX_BRAKING_VALUE);
                        valueChanged = true;
                    }
                } else {
                    if (currentBraking > 0) {
                        currentBraking -= brakeDecreaseRatePerMs * timeDelta;
                        currentBraking = Math.max(currentBraking, 0);
                        valueChanged = true;
                    }
                }

                if (valueChanged) {
                    brakingValue = currentBraking;
                    updateBrakingUI();
                    sendControlValues();
                }

                boolean shouldContinue = (isBrakeButtonHeld && brakingValue < MAX_BRAKING_VALUE) ||
                        (!isBrakeButtonHeld && brakingValue > 0);

                if (shouldContinue) {
                    controlUpdateHandler.postDelayed(this, UPDATE_INTERVAL_MS);
                } else {
                    isBrakeRunnableScheduled = false;
                    if (valueChanged) {
                        sendControlValues();
                    }
                }
            }
        };
    }

    private void loadBrakeSettings() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        brakeIncreaseRatePerMs = prefs.getFloat(KEY_INCREASE_RATE, 0.1f);
        brakeDecreaseRatePerMs = prefs.getFloat(KEY_DECREASE_RATE, 0.05f);
    }

    private void saveBrakeSettings(float increaseRate, float decreaseRate) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putFloat(KEY_INCREASE_RATE, increaseRate);
        editor.putFloat(KEY_DECREASE_RATE, decreaseRate);
        editor.apply();

        brakeIncreaseRatePerMs = increaseRate;
        brakeDecreaseRatePerMs = decreaseRate;
    }

    private void showSettingsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.dialog_title_brake_settings);

        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_brake_settings, null);
        builder.setView(dialogView);

        final TextInputLayout inputLayoutIncreaseRate = dialogView.findViewById(R.id.inputLayoutIncreaseRate);
        final TextInputEditText editTextIncreaseRate = dialogView.findViewById(R.id.editTextIncreaseRate);
        final TextInputLayout inputLayoutDecreaseRate = dialogView.findViewById(R.id.inputLayoutDecreaseRate);
        final TextInputEditText editTextDecreaseRate = dialogView.findViewById(R.id.editTextDecreaseRate);

        editTextIncreaseRate.setText(String.valueOf(brakeIncreaseRatePerMs));
        editTextDecreaseRate.setText(String.valueOf(brakeDecreaseRatePerMs));

        builder.setPositiveButton(R.string.button_save, null);
        builder.setNegativeButton(R.string.button_cancel, (dialog, which) -> dialog.cancel());

        AlertDialog dialog = builder.create();

        dialog.setOnShowListener(dialogInterface -> {
            Button button = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            button.setOnClickListener(view -> {
                String increaseRateStr = Objects.requireNonNull(editTextIncreaseRate.getText()).toString();
                String decreaseRateStr = Objects.requireNonNull(editTextDecreaseRate.getText()).toString();
                boolean valid = true;

                inputLayoutIncreaseRate.setError(null);
                inputLayoutDecreaseRate.setError(null);

                float newIncreaseRate = -1f;
                float newDecreaseRate = -1f;

                try {
                    newIncreaseRate = Float.parseFloat(increaseRateStr);
                    if (newIncreaseRate <= 0) {
                        inputLayoutIncreaseRate.setError(getString(R.string.error_invalid_input)); // Reverted
                        valid = false;
                    }
                } catch (NumberFormatException e) {
                    inputLayoutIncreaseRate.setError(getString(R.string.error_invalid_input)); // Reverted
                    valid = false;
                }

                try {
                    newDecreaseRate = Float.parseFloat(decreaseRateStr);
                    if (newDecreaseRate <= 0) {
                        inputLayoutDecreaseRate.setError(getString(R.string.error_invalid_input)); // Reverted
                        valid = false;
                    }
                } catch (NumberFormatException e) {
                    inputLayoutDecreaseRate.setError(getString(R.string.error_invalid_input)); // Reverted
                    valid = false;
                }

                if (valid) {
                    saveBrakeSettings(newIncreaseRate, newDecreaseRate);
                    dialog.dismiss();
                }
            });
        });

        dialog.show();
    }

    private void updateBrakingUI() {
        runOnUiThread(() -> txtBrakingValue.setText(String.format(Locale.ENGLISH, getString(R.string.braking_format), (int) brakingValue)));
    }

    private void updateSteeringUI(int displayAngle, int power) {
        runOnUiThread(() -> txtSteeringInfo.setText(String.format(Locale.ENGLISH, getString(R.string.steering_info_format),
                displayAngle, power, currentDirection)));
    }


    @Override
    public void onStatusChanged(SteeringWheelView view, int displayAngle, int power, int direction, int linearSteeringValue) {
        updateDirectionText(direction);
        this.steeringAngle = (power == 0) ? STEERING_CENTER_VALUE : linearSteeringValue;
        updateSteeringUI(displayAngle, power);
        sendControlValues();
    }


    private void updateDirectionText(int direction) {
        switch (direction) {
            case SteeringWheelView.LEFT:
                currentDirection = getString(R.string.steering_direction_left);
                break;
            case SteeringWheelView.RIGHT:
                currentDirection = getString(R.string.steering_direction_right);
                break;
            case SteeringWheelView.INVALID:
            default:
                currentDirection = getString(R.string.steering_direction_idle);
                break;
        }
    }

    private void sendControlValues() {
        int currentSteering = this.steeringAngle;
        int currentBraking = (int) this.brakingValue;
        mFirebaseManager.sendCombinedControlValues(currentSteering, currentBraking, 0, 0,0,0);
        runOnUiThread(() -> txtStatus.setText(String.format(Locale.ENGLISH, getString(R.string.status_sent_format), currentSteering, currentBraking, 0, 0 ,0 ,0 )));
    }

    @Override
    public void onCommandSent(boolean success, String command, @Nullable String error) {
        if (!success) {
            runOnUiThread(() -> {
                String statusMessage = String.format(Locale.ENGLISH, getString(R.string.status_error_format), command, error);
                txtStatus.setText(statusMessage);
            });
        }
    }

    @Override
    public void onInitialControlValues(int steeringFromFirebase, int brakingFromFirebase) {
        if (!getIntent().hasExtra("STEERING_VALUE")) {
            this.steeringAngle = steeringFromFirebase;
        }
        this.brakingValue = brakingFromFirebase;

        runOnUiThread(() -> {
            updateDirectionText(SteeringWheelView.INVALID);
            updateSteeringUI(90, 0);
            mSteeringWheel.setAngle(this.steeringAngle);
            updateBrakingUI();
            txtStatus.setText(R.string.status_sync_completed);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        controlUpdateHandler.removeCallbacks(brakeUpdateRunnable);
        isBrakeRunnableScheduled = false;
        if (mFirebaseManager != null) {
            mFirebaseManager.cleanup();
        }
    }
}