package com.espcontrol;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicInteger;

public class CommandLogger {
    private static final String TAG = "CommandLogger";
    private static final String PATH_STATISTICS = "devices/esp32s3/statistics";
    private final DatabaseReference mStatisticsRef;
    private LoggingStatusCallback mCallback;
    private boolean mIsLogging = false;
    private String mSessionId;
    private int mTimeInterval = 1;
    private int mDuration = 60;
    private final AtomicInteger mCommandCounter = new AtomicInteger(0);
    private int mCurrentStep = 0;
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private final Map<Integer, Integer> mTimeSeriesData = new HashMap<>();

    public interface LoggingStatusCallback {
        void onLoggingStarted(String sessionId);
        void onLoggingStep(int step, int commandCount, int totalSteps);
        void onLoggingCompleted(String sessionId, int totalCommands);
        void onLoggingError(String errorMessage);
    }

    public CommandLogger(LoggingStatusCallback callback) {
        mCallback = callback;
        mStatisticsRef = FirebaseDatabase.getInstance().getReference().child(PATH_STATISTICS);
    }

    public boolean startLogging(int intervalSeconds, int durationSeconds) {
        if (mIsLogging) {
            Log.w(TAG, "Logging already in progress");
            return false;
        }

        if (intervalSeconds <= 0 || durationSeconds <= 0) {
            Log.e(TAG, "Invalid parameters: interval and duration must be positive");
            if (mCallback != null) {
                mCallback.onLoggingError("Invalid parameters: interval and duration must be positive");
            }
            return false;
        }

        mTimeInterval = intervalSeconds;
        mDuration = durationSeconds;
        mSessionId = generateSessionId();
        mCommandCounter.set(0);
        mCurrentStep = 0;
        mTimeSeriesData.clear();

        initializeSessionStructure(mSessionId, intervalSeconds, durationSeconds);

        return true;
    }

    private void initializeSessionStructure(String sessionId, int intervalSeconds, int durationSeconds) {
        Log.d(TAG, "Initializing session structure: " + sessionId);

        Map<String, Object> sessionData = new HashMap<>();
        String timestamp = getTimestamp();
        sessionData.put("timestamp", timestamp);
        sessionData.put("interval_seconds", intervalSeconds);
        sessionData.put("duration_seconds", durationSeconds);
        sessionData.put("created_by", "Kostovite");
        sessionData.put("device", "Android App");
        sessionData.put("status", "initializing");

        mStatisticsRef.child("sessions").child(sessionId).setValue(sessionData)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Session structure created successfully");

                    setupSynchronizedLogging(sessionId, intervalSeconds, durationSeconds, timestamp);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Failed to create session structure: " + e.getMessage());
                    if (mCallback != null) {
                        mCallback.onLoggingError("Failed to create session: " + e.getMessage());
                    }
                });
    }

    private void setupSynchronizedLogging(String sessionId, int intervalSeconds, int durationSeconds, String timestamp) {
        // Create synchronized start configuration
        Map<String, Object> loggingConfig = new HashMap<>();
        loggingConfig.put("session_id", sessionId);
        loggingConfig.put("interval_seconds", intervalSeconds);
        loggingConfig.put("duration_seconds", durationSeconds);
        loggingConfig.put("timestamp", timestamp);
        loggingConfig.put("start_signal", true);

        DatabaseReference configRef = FirebaseDatabase.getInstance().getReference()
                .child("devices/esp32s3/logging_config");

        configRef.setValue(loggingConfig)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Logging configuration set, ESP will detect and join");

                    // Update session status
                    mStatisticsRef.child("sessions").child(sessionId).child("status").setValue("active");

                    // Start logging in this app
                    mIsLogging = true;
                    if (mCallback != null) {
                        mCallback.onLoggingStarted(sessionId);
                    }

                    logStep();
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Failed to set logging configuration: " + e.getMessage());
                    if (mCallback != null) {
                        mCallback.onLoggingError("Failed to signal ESP: " + e.getMessage());
                    }
                });
    }

    public void stopLogging() {
        if (!mIsLogging) {
            Log.w(TAG, "No logging in progress to stop");
            return;
        }

        mHandler.removeCallbacksAndMessages(null);

        if (mCommandCounter.get() > 0) {
            int finalStep = mCurrentStep + 1;
            int finalCount = mCommandCounter.getAndSet(0);
            mTimeSeriesData.put(finalStep, finalCount);

            // Upload the final step
            mStatisticsRef.child("sessions").child(mSessionId).child("time_series")
                    .child(String.valueOf(finalStep)).setValue(finalCount);
        }

        mIsLogging = false;
        uploadLoggingResults();

        // Signal ESP to stop logging
        Map<String, Object> stopSignal = new HashMap<>();
        stopSignal.put("start_signal", false);
        stopSignal.put("stop_signal", true);

        DatabaseReference configRef = FirebaseDatabase.getInstance().getReference()
                .child("devices/esp32s3/logging_config");

        configRef.updateChildren(stopSignal)
                .addOnSuccessListener(aVoid -> Log.d(TAG, "ESP notified to stop logging"))
                .addOnFailureListener(e -> Log.e(TAG, "Failed to notify ESP to stop: " + e.getMessage()));

        Log.d(TAG, "Logging stopped and results uploaded");
    }

    public void incrementCommandCount() {
        if (mIsLogging) {
            mCommandCounter.incrementAndGet();
        }
    }

    public boolean isLogging() {
        return mIsLogging;
    }

    public void setCallback(LoggingStatusCallback callback) {
        mCallback = callback;
    }

    public void cleanup() {
        if (mIsLogging) {
            stopLogging();
        }

        mHandler.removeCallbacksAndMessages(null);
        mCallback = null;
    }

    private void logStep() {
        mCurrentStep++;
        int commandCount = mCommandCounter.getAndSet(0);
        mTimeSeriesData.put(mCurrentStep, commandCount);

        Log.d(TAG, "Logging step " + mCurrentStep + ": " + commandCount + " commands");

        String stepKey = String.valueOf(mCurrentStep);
        mStatisticsRef.child("sessions").child(mSessionId).child("time_series").child(stepKey)
                .setValue(commandCount)
                .addOnSuccessListener(aVoid -> Log.d(TAG, "Step " + mCurrentStep + " uploaded successfully"))
                .addOnFailureListener(e -> Log.e(TAG, "Error uploading step " + mCurrentStep + ": " + e.getMessage()));

        if (mCallback != null) {
            int totalSteps = mDuration / mTimeInterval;
            mCallback.onLoggingStep(mCurrentStep, commandCount, totalSteps);
        }

        if (mCurrentStep * mTimeInterval < mDuration && mIsLogging) {
            mHandler.postDelayed(this::logStep, mTimeInterval * 1000L);
        } else {
            mIsLogging = false;
            uploadLoggingResults();
        }
    }

    private void uploadLoggingResults() {
        Map<String, Object> sessionData = new HashMap<>();
        sessionData.put("status", "completed");
        sessionData.put("end_time", getTimestamp());

        int totalCommands = 0;
        int maxCommands = 0;
        for (Integer count : mTimeSeriesData.values()) {
            totalCommands += count;
            maxCommands = Math.max(maxCommands, count);
        }

        sessionData.put("total_commands", totalCommands);
        sessionData.put("max_commands_per_interval", maxCommands);
        float avgCommands = !mTimeSeriesData.isEmpty() ?
                (float)totalCommands / mTimeSeriesData.size() : 0;
        sessionData.put("average_commands_per_interval", avgCommands);

        int finalTotalCommands = totalCommands;
        mStatisticsRef.child("sessions").child(mSessionId).updateChildren(sessionData)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Statistics uploaded successfully to session: " + mSessionId);
                    if (mCallback != null) {
                        mCallback.onLoggingCompleted(mSessionId, finalTotalCommands);
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error uploading statistics: " + e.getMessage());
                    if (mCallback != null) {
                        mCallback.onLoggingError("Failed to upload data: " + e.getMessage());
                    }
                });
    }

    private String generateSessionId() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date());
    }

    private String getTimestamp() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date());
    }
}